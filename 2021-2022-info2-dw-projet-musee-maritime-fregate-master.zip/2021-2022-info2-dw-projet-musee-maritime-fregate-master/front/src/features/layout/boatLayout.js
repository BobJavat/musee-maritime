import {Outlet} from "react-router-dom";

const BoatLayout = () => {
    return (
        <>
            <Outlet />
        </>
    )
}

export default BoatLayout
