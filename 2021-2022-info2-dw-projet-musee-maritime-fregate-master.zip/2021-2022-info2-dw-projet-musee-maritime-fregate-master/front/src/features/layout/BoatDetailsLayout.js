import {Outlet} from "react-router-dom";

const BoatDetailsLayout = () => {
    return (
        <>
            <Outlet />
        </>
    )
}

export default BoatDetailsLayout