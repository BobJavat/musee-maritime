const Header = () => {
    return (
        <>
            <div className="headerContainer">
                <div className="titleHeaderContainer">
                    <p className="titleHeader">Bassin à flot histoire et témoignages</p>
                </div>
            </div>
        </>
    )
}

export default Header