import '../../App.css';
import '../../boatsList_style.css';

// Composant contenant l'entete de la page
const BoatsHead = () => {
    return (
        <>
            <div className="headerContainer">
            </div>
            <div className="pageTitle">
                Visitez nos bateaux !
            </div>
        </>
    )
}

export default BoatsHead